# 数据分析报告

## 基本统计信息
- 总用户数: 497
- 覆盖国家数: 52
- 覆盖地区数: 344
- 事件类型数: 15

## Top 5 统计
### Top 5 国家
- United States: 305788条记录
- Germany: 182659条记录
- China: 73011条记录
- United Kingdom: 71606条记录
- France: 59570条记录

### Top 5 地区
- Germany: 107747条记录
- Prague: 37757条记录
- Japan: 26986条记录
- Palo Alto, CA: 19215条记录
- UK: 17789条记录

### Top 5 影响力用户
- bdraco: 1776.9671630859375
- bdraco: 1776.9671630859375
- bdraco: 1776.9671630859375
- bdraco: 1776.9671630859375
- bdraco: 1776.9671630859375

### 最常见事件类型
- PushEvent: 410955次
- PullRequestEvent: 201128次
- IssueCommentEvent: 174806次
- PullRequestReviewEvent: 151843次
- CreateEvent: 104371次

## 时间模式分析
- 最活跃时段: 15:00
- 最活跃工作日: Wednesday
- 最活跃月份: October
