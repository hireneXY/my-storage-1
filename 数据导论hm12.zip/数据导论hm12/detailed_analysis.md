# 详细统计分析报告

## 1. 基础统计量

### 数值型变量统计
```
            user_id  total_influence
count  1.294776e+06     1.294776e+06
mean   1.325567e+07     5.440863e+02
std    1.953129e+07     2.578072e+02
min    2.250000e+02     3.385323e+02
25%    6.634320e+05     3.900486e+02
50%    4.582016e+06     4.552713e+02
75%    1.806696e+07     5.748544e+02
max    1.128264e+08     1.776967e+03
```

## 2. 用户统计

- 总用户数：497
- 总记录数：1294776
- 平均每用户记录数：2605.18

## 3. 地理分布

### 国家分布 (Top 10)
```
United States     305788
Germany           182659
China              73011
United Kingdom     71606
France             59570
Canada             58600
Netherlands        52367
Czechia            48122
Japan              46553
Switzerland        38093
Name: country, dtype: int64
```

### 地理位置分布 (Top 10)
```
Germany          107747
Prague            37757
Japan             26986
Palo Alto, CA     19215
UK                17789
NYC               16381
San Francisco     16271
Paris, France     16021
Switzerland       15555
Houston, TX       15449
Name: location, dtype: int64
```

## 4. 事件分析

### 事件类型分布
```
PushEvent                        410955
PullRequestEvent                 201128
IssueCommentEvent                174806
PullRequestReviewEvent           151843
CreateEvent                      104371
DeleteEvent                       96999
PullRequestReviewCommentEvent     86198
IssuesEvent                       51205
ReleaseEvent                       9455
WatchEvent                         3809
ForkEvent                          2175
CommitCommentEvent                  704
GollumEvent                         683
MemberEvent                         390
PublicEvent                          55
Name: event_type, dtype: int64
```

### 事件行为分布 (Top 10)
```
added        617218
created      411961
closed       173489
opened        76406
published      9455
started        3809
reopened       2438
Name: event_action, dtype: int64
```

## 5. 影响力分析

### 影响力统计量
```
count    1.294776e+06
mean     5.440863e+02
std      2.578072e+02
min      3.385323e+02
25%      3.900486e+02
50%      4.552713e+02
75%      5.748544e+02
max      1.776967e+03
Name: total_influence, dtype: float64
```

### Top 10 影响力用户
```
     name  total_influence        country
0  bdraco      1776.967163  United States
1  bdraco      1776.967163  United States
2  bdraco      1776.967163  United States
3  bdraco      1776.967163  United States
4  bdraco      1776.967163  United States
5  bdraco      1776.967163  United States
6  bdraco      1776.967163  United States
7  bdraco      1776.967163  United States
8  bdraco      1776.967163  United States
9  bdraco      1776.967163  United States
```

## 6. 时间分析

### 每小时活动统计
```
0     37121
1     39586
2     35464
3     32763
4     31255
5     32077
6     41740
7     63000
8     56851
9     64111
10    64592
11    62849
12    64103
13    69941
14    71059
15    71302
16    68460
17    61251
18    60701
19    60547
20    56297
21    53304
22    51274
23    45128
Name: event_datetime, dtype: int64
```

### 每周日活动统计
```
Wednesday    238827
Tuesday      225084
Thursday     213285
Friday       199702
Monday       193102
Saturday     120157
Sunday       104619
Name: event_datetime, dtype: int64
```

### 月度活动统计
```
October     679868
November    614908
Name: event_datetime, dtype: int64
```

