import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import glob
import os
from datetime import datetime

# 读取所有CSV文件
csv_files = glob.glob('users_combined_info_500_part_*.csv')
dfs = []
for file in csv_files:
    df = pd.read_csv(file)
    dfs.append(df)

# 合并所有数据框
df_combined = pd.concat(dfs, ignore_index=True)

# 1. 人口统计分析
def demographic_analysis(df):
    # 国家分布
    country_dist = df['country'].value_counts().head(10)
    fig_country = px.bar(
        x=country_dist.index,
        y=country_dist.values,
        title='各国用户分布 (Top 10)',
        labels={'x': '国家', 'y': '用户数量'}
    )
    fig_country.write_html('country_distribution.html')

    # 地理位置分布
    location_dist = df['location'].value_counts().head(10)
    fig_location = px.bar(
        x=location_dist.index,
        y=location_dist.values,
        title='地理位置分布 (Top 10)',
        labels={'x': '地理位置', 'y': '用户数量'}
    )
    fig_location.write_html('location_distribution.html')

    # 事件类型分布
    event_type_dist = df['event_type'].value_counts()
    fig_event = px.pie(
        values=event_type_dist.values,
        names=event_type_dist.index,
        title='事件类型分布'
    )
    fig_event.write_html('event_type_distribution.html')

# 2. 行为分析
def behavior_analysis(df):
    # 用户影响力分布
    influence_labels = ['很低', '低', '中等', '高', '很高']
    influence_dist = pd.qcut(df['total_influence'], q=5, labels=influence_labels)
    influence_counts = influence_dist.value_counts()
    fig_influence = px.pie(
        values=influence_counts.values,
        names=influence_counts.index,
        title='用户影响力分布'
    )
    fig_influence.write_html('influence_distribution.html')

    # 事件行为分析
    action_dist = df['event_action'].value_counts().head(10)
    fig_action = px.bar(
        x=action_dist.index,
        y=action_dist.values,
        title='用户行为分布 (Top 10)',
        labels={'x': '行为类型', 'y': '次数'}
    )
    fig_action.write_html('action_distribution.html')

# 3. 时间模式分析
def time_pattern_analysis(df):
    # 转换时间列
    df['event_datetime'] = pd.to_datetime(df['event_time'])
    
    # 提取时间特征
    df['hour'] = df['event_datetime'].dt.hour
    df['weekday'] = df['event_datetime'].dt.day_name()
    df['month'] = df['event_datetime'].dt.month_name()
    
    # 每小时活动分布
    hour_dist = df['hour'].value_counts().sort_index()
    fig_hour = px.line(
        x=hour_dist.index,
        y=hour_dist.values,
        title='24小时活动分布',
        labels={'x': '小时', 'y': '活动次数'}
    )
    fig_hour.write_html('hourly_activity_distribution.html')
    
    # 工作日活动分布
    weekday_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    weekday_dist = df['weekday'].value_counts().reindex(weekday_order)
    fig_weekday = px.bar(
        x=weekday_dist.index,
        y=weekday_dist.values,
        title='工作日活动分布',
        labels={'x': '星期', 'y': '活动次数'}
    )
    fig_weekday.write_html('weekday_activity_distribution.html')
    
    # 月度活动分布
    month_order = ['January', 'February', 'March', 'April', 'May', 'June', 
                  'July', 'August', 'September', 'October', 'November', 'December']
    month_dist = df['month'].value_counts().reindex(month_order)
    fig_month = px.bar(
        x=month_dist.index,
        y=month_dist.values,
        title='月度活动分布',
        labels={'x': '月份', 'y': '活动次数'}
    )
    fig_month.write_html('monthly_activity_distribution.html')
    
    # 热力图：小时-工作日分布
    pivot_table = df.pivot_table(
        values='user_id',
        index='weekday',
        columns='hour',
        aggfunc='count',
        fill_value=0
    ).reindex(weekday_order)
    
    fig_heatmap = go.Figure(data=go.Heatmap(
        z=pivot_table.values,
        x=pivot_table.columns,
        y=pivot_table.index,
        colorscale='Viridis'
    ))
    fig_heatmap.update_layout(
        title='活动时间热力图',
        xaxis_title='小时',
        yaxis_title='星期'
    )
    fig_heatmap.write_html('activity_heatmap.html')

def main():
    # 执行分析
    demographic_analysis(df_combined)
    behavior_analysis(df_combined)
    time_pattern_analysis(df_combined)
    
    # 生成汇总报告
    with open('analysis_report.md', 'w', encoding='utf-8') as f:
        f.write('# 数据分析报告\n\n')
        
        # 基本统计信息
        f.write('## 基本统计信息\n')
        f.write(f'- 总用户数: {len(df_combined["user_id"].unique())}\n')
        f.write(f'- 覆盖国家数: {df_combined["country"].nunique()}\n')
        f.write(f'- 覆盖地区数: {df_combined["location"].nunique()}\n')
        f.write(f'- 事件类型数: {df_combined["event_type"].nunique()}\n\n')
        
        # Top 5 统计
        f.write('## Top 5 统计\n')
        f.write('### Top 5 国家\n')
        for country, count in df_combined['country'].value_counts().head().items():
            f.write(f'- {country}: {count}条记录\n')
        
        f.write('\n### Top 5 地区\n')
        for location, count in df_combined['location'].value_counts().head().items():
            f.write(f'- {location}: {count}条记录\n')
        
        f.write('\n### Top 5 影响力用户\n')
        top_users = df_combined.nlargest(5, 'total_influence')[['name', 'total_influence']]
        for _, row in top_users.iterrows():
            f.write(f'- {row["name"]}: {row["total_influence"]}\n')
        
        f.write('\n### 最常见事件类型\n')
        for event_type, count in df_combined['event_type'].value_counts().head().items():
            f.write(f'- {event_type}: {count}次\n')
        
        # 时间模式分析
        f.write('\n## 时间模式分析\n')
        
        # 活跃时段
        peak_hour = df_combined['event_datetime'].dt.hour.mode().iloc[0]
        f.write(f'- 最活跃时段: {peak_hour}:00\n')
        
        # 最活跃工作日
        peak_weekday = df_combined['event_datetime'].dt.day_name().mode().iloc[0]
        f.write(f'- 最活跃工作日: {peak_weekday}\n')
        
        # 最活跃月份
        peak_month = df_combined['event_datetime'].dt.month_name().mode().iloc[0]
        f.write(f'- 最活跃月份: {peak_month}\n')

if __name__ == '__main__':
    main() 